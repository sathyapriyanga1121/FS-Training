
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class registerservlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String uname=request.getParameter("email");
		String pass=request.getParameter("pass");
		String name=request.getParameter("uname");

		PrintWriter out=response.getWriter();
		try {
			ServletConfig config=getServletConfig();
			String name1=config.getInitParameter("name");
			System.out.println(name1);
			ServletContext context= getServletContext();
			String driver=context.getInitParameter("driverclass");
			String urlc=context.getInitParameter("url");
			String userc=context.getInitParameter("user");
			String passwc=context.getInitParameter("passw");

			//load the driver class
				Class.forName(driver);
			
			//create the connection
			Connection conn=DriverManager.getConnection(urlc,userc,passwc);
			
			//create the statement
		    PreparedStatement stat=conn.prepareStatement("insert into gmail values(?,?,?)");
		    stat.setString(1,uname);
		    stat.setString(2, pass);
		    stat.setString(3,name);
		    
		    int res=stat.executeUpdate();
		    if(res>0)
		    {
		    	RequestDispatcher rd=request.getRequestDispatcher("login.html");
		    	rd.forward(request, response);
		    	out.println("Registered successfully");
		    
		    }
		    else
		    {
		    	RequestDispatcher rd=request.getRequestDispatcher("register.html");
		    	rd.include(request, response);
		    	out.println("Please enter the valid credentials");
		    }
		     
		    
		    
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Invalid Input");
			}
			
		}

		

	}
