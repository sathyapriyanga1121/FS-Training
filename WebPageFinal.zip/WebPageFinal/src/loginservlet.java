import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name=request.getParameter("uname");
		String pass=request.getParameter("pass");
		PrintWriter out=response.getWriter();
		
		try {
			ServletConfig config=getServletConfig();
			String name1=config.getInitParameter("name");
			System.out.println(name1);
			ServletContext context= getServletContext();
			String driver=context.getInitParameter("driverclass");
			String urlc=context.getInitParameter("url");
			String userc=context.getInitParameter("user");
			String passwc=context.getInitParameter("passw");

			//load the driver class
				Class.forName(driver);
			
			//create the connection
			Connection conn=DriverManager.getConnection(urlc,userc,passwc);
		//create the statement
	    PreparedStatement stat=conn.prepareStatement("select * from gmail where username=? and password=?");
	    stat.setString(1,name);
	    stat.setString(2, pass);
	    
	    ResultSet res=stat.executeQuery();
	    if(res.next())
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("home.html");
	    	rd.forward(request, response);
	    	out.println("Welcome to home page "+res.getString(3));
	    }
	    else
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("login.html");
	    	rd.include(request, response);
	    	out.println("Please enter the valid credentials");
	    }
	     
	    
	    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid Input");
		}
		
	}

	

}
