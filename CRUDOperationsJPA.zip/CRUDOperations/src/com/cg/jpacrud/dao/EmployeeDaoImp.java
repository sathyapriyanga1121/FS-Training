package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.jpacrud.entities.EmployeeInf;

@Repository
public class EmployeeDaoImp implements EmployeeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
	@Transactional
	public void addEmployee(EmployeeInf emp) {
		entityManager.persist(emp);
		
	}

	@Override
	public EmployeeInf findEmployee(int id) {
		EmployeeInf emp=entityManager.find(EmployeeInf.class, id);
		return emp;
	}

	@Override
	@Transactional
	public void updateEmployee(EmployeeInf emp) {
		entityManager.merge(emp);
		
	}

	@Override
	@Transactional
	public void deleteEmployee(int id) {
		EmployeeInf emp = findEmployee(id);
		entityManager.remove(emp);
		
	}
	
	@Override
	public List print() {
		TypedQuery<EmployeeInf> q2=entityManager.createQuery("select c from EmployeeInf c",EmployeeInf.class);
        List<EmployeeInf> l1=q2.getResultList();
        for(EmployeeInf e4:l1)
        {
        	System.out.println("**********************");
            System.out.println(e4.getId());
            System.out.println(e4.getName());
        	System.out.println("**********************");

        }
		return l1;
	}
}

