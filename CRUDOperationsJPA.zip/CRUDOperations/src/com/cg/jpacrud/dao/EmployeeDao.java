package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.Query;

import com.cg.jpacrud.entities.EmployeeInf;

public interface EmployeeDao {

	void addEmployee(EmployeeInf emp);

	EmployeeInf findEmployee(int id);

	void updateEmployee(EmployeeInf emp);

	void deleteEmployee(int id);

	List print();
}
