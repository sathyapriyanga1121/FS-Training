package com.cg.jpacrud.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="capemp")
public class EmployeeInf {

	@Id
	private int id;
	@Column(name="empname",length=10)
	private String name;
	@Column(name="empadd",length=10)
	private String add;
	@Column(name="empsal",length=10)
	private int sal;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
public EmployeeInf() {
	// TODO Auto-generated constructor stub
}
public EmployeeInf(int id, String name, String add, int sal) {
	super();
	this.id = id;
	this.name = name;
	this.add = add;
	this.sal = sal;
}

}
