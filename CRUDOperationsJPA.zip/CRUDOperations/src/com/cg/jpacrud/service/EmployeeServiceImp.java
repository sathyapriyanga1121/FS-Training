package com.cg.jpacrud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.jpacrud.dao.EmployeeDao;
import com.cg.jpacrud.entities.EmployeeInf;
@Service("employeeService")
public class EmployeeServiceImp implements EmployeeService {

	private EmployeeDao dao;

	@Autowired
	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}

	@Override
	public EmployeeInf findEmployee(int id) {
		EmployeeInf emp = dao.findEmployee(id);
		return emp;
	}

	@Override
	public void updateEmployee(EmployeeInf emp) {
		dao.updateEmployee(emp);

	}

	@Override
	public void deleteEmployee(int id) {
		dao.deleteEmployee(id);
	}

	@Override
	public void addEmployee(EmployeeInf emp) {
		dao.addEmployee(emp);

	}

	@Override
	public List print() {
		List q=dao.print();
		return q;
	}

}
