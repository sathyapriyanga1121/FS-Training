package com.cg.jpacrud.service;

import java.util.List;

import javax.persistence.Query;

import com.cg.jpacrud.employee.Employee;
import com.cg.jpacrud.entities.EmployeeInf;

public interface EmployeeService {

	void addEmployee(EmployeeInf emp);

	EmployeeInf findEmployee(int id);

	void updateEmployee(EmployeeInf emp);

	void deleteEmployee(int id);

	List print();

}
