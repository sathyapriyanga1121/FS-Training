package com.cg.jpacrud.employee;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.jpacrud.entities.EmployeeInf;
import com.cg.jpacrud.service.EmployeeService;

public class Employee {
	public static void main(String[] args) {

		ApplicationContext context= new ClassPathXmlApplicationContext("app.xml");
		EmployeeService service=(EmployeeService) context.getBean("employeeService");
		
		while (true) {
			System.out.println("CRUD OPERATIONS");
			System.out.println("1.CREATE EMPLOYEE");
			System.out.println("2.FIND EMPLOYEE");
			System.out.println("3.UPDATE EMPLOYEE");
			System.out.println("4.DELETE EMPLOYEE");
			System.out.println("5.LIST EMPLOYEE");
			System.out.println("SELECT ANY OPTION..");
			Scanner sc = new Scanner(System.in);
			int option = sc.nextInt();

			switch (option) {
			case 1:

				System.out.println("Enter employee id");
				int id = sc.nextInt();
				System.out.println("Enter employee name");
				String name = sc.next();
				System.out.println("Enter employee address");
				String add = sc.next();
				System.out.println("Enter employee salary");
				int sal = sc.nextInt();
				EmployeeInf emp = new EmployeeInf(id, name, add, sal);
				service.addEmployee(emp);
				
				break;
				
				
			case 2:

				System.out.println("Enter employee id");
				int id3 = sc.nextInt();
				EmployeeInf empInf = service.findEmployee(id3);
				if(empInf!=null)
				{
				System.out.println("Name:" + empInf.getName());
				}
				else
				{
					System.out.println("Invalid id");
				}
				
				break;
				
				
			case 3:

				System.out.println("Enter employee id for which you need to update");
				int id4 = sc.nextInt();
				EmployeeInf emp2 = service.findEmployee(id4);
				if(emp2!=null)
				{
				System.out.println("Enter the name: ");
				String name1 = sc.next();
				emp2.setName(name1);
				service.updateEmployee(emp2);
				System.out.println(emp2.getName());
				}
				
				else
				{
					System.out.println("Invalid id");
				}
				break;

				
			case 4:

				System.out.println("Enter employee id to be deleted");
				int id1 = sc.nextInt();
				EmployeeInf emp3 = service.findEmployee(id1);
				if(emp3!=null)
				{
				service.deleteEmployee(id1);
				System.out.println("Record deleted");
				}
				
				else
				{
					System.out.println("Invalid id");
				}
				break;
				
			case 5:
				System.out.println("Transaction Details");
				service.print();
                
			}
		}

	}
}
