package com.cap.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entity.Stock;
import com.cap.exception.IdNotFoundException;
import com.cap.service.StockService;

@RestController
@RequestMapping("/stock")
public class StockTradingController {
	@Autowired
	StockService service;
	
	
	@PostMapping("/CreateStock")
	public List<Stock> createStock(@RequestBody Stock stock) {
		return service.createStock(stock);
	}
	
	
	@PutMapping(value="/updateStock/{id}")
	public List<Stock> updateStock(@Valid @PathVariable int id, @RequestBody Stock stock) throws IdNotFoundException
	{
		return service.updateStock(id,stock);
	}

	 @DeleteMapping("delete/{id}")
	    public ResponseEntity<String> deleteEmployeeById(@PathVariable("id") int id)
	                                                    throws IdNotFoundException {
	        service.deleteStock(id);
	        return new ResponseEntity<String>("Data Deleted", HttpStatus.FORBIDDEN);
	    }

	 
	 @GetMapping("/stockDetails/{id}")
		public ResponseEntity<String> stockDetails(@PathVariable int id)  throws IdNotFoundException{
			Stock stock = service.findStock(id);
			return new ResponseEntity<String>("Stock Details\n"+stock, HttpStatus.OK);
		}
	 
	 @GetMapping("/listAllStock")
	    public ResponseEntity<List<Stock>> getAllEmployees()  throws IdNotFoundException{
	        List<Stock> list = service.viewAllStock();
	 
	        return new ResponseEntity<List<Stock>>(list, new HttpHeaders(), HttpStatus.OK);
	    }
}
