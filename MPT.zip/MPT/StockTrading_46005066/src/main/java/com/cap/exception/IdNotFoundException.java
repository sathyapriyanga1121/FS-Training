package com.cap.exception;

public class IdNotFoundException extends RuntimeException {
    //user defined exception for invalid account number 
    private static final long serialVersionUID = 1L;

 

    public IdNotFoundException(final String msg){
        super(msg);
    }
     
    }
