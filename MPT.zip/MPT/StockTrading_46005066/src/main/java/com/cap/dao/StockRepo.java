package com.cap.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cap.entity.Stock;

public interface StockRepo extends JpaRepository<Stock, Integer> {

}
