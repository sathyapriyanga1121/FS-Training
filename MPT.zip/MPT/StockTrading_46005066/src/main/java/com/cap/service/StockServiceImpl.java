package com.cap.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.StockRepo;
import com.cap.entity.Stock;
import com.cap.exception.IdNotFoundException;

@Service
public class StockServiceImpl implements StockService {

	@Autowired
	StockRepo repo;
	@Autowired
	private StockService service;

	@Override
	public List<Stock> createStock(Stock bean) {
		
		calculateOrder(bean);
		repo.save(bean);
		return repo.findAll();
		
	}
	@Override
	public List<Stock> updateStock(int id, Stock stock) throws IdNotFoundException  {
		try {
			service.calculateOrder(stock);
			stock.setPrice(stock.getPrice());
			stock.setQuantity(stock.getQuantity());
			repo.save(stock);
			return repo.findAll();
		} 
		catch (Exception e) {
			throw new IdNotFoundException(e.getMessage());
		}
	}

	

	@Override
	public String deleteStock(int id) throws IdNotFoundException {
		// TODO Auto-generated method stub

		Optional<Stock> stock = repo.findById(id);

		if (stock.isPresent()) {
			repo.deleteById(id);
		}

		else {
			throw new IdNotFoundException("No record exist for given id");
		}
		return "The Stock details of " + id + " is deleted";
	}

	@Override
	public Stock findStock(int id) throws IdNotFoundException {

		Optional<Stock> stock = repo.findById(id);
		
		if (stock.isPresent()) {
		return stock.get();
		}
		else {
			throw new IdNotFoundException("No record exist for given id");
		}
		
	}

	@Override
	public List<Stock> viewAllStock() {

		List<Stock> stockList = repo.findAll();

		if (stockList.size() > 0) {
			return stockList;
		} else {
			return new ArrayList<Stock>();

		}
	}

	@Override
	public int calculateOrder(Stock bean) {

		double price = bean.getPrice();
		int quantity = bean.getQuantity();
		double amt = price * quantity;
		double result;
		if (quantity > 100) 
		{
			result = (amt * (0.3)) / 100;
		}
		else 
		{
			result = (amt * (0.5)) / 100;
		}
		bean.setAmount(amt);
		bean.setBrokerage(result);
		return 0;
	}



	
}
