package com.cap.service;

import java.util.List;

import com.cap.entity.Stock;
import com.cap.exception.IdNotFoundException;

public interface StockService {

	List<Stock> createStock(Stock bean);

    List<Stock> viewAllStock();
	
	int calculateOrder(Stock bean);

	String deleteStock(int id);

	Stock findStock(int id);

	List<Stock> updateStock(int id, Stock stock);
		
}
