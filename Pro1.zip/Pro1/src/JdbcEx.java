import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcEx {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
	//load the driver class
	Class.forName("oracle.jdbc.driver.OracleDriver");
	
	//create the connection
	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg401","training401");
	
	//create the statement
    Statement stat=conn.createStatement();
    
    //execute query boolean 
    //boolean execute()-->ddl
    //int executeUpdate-->dml
    //Resultset executeQuery-->select
    
     // boolean result=stat.execute("create table dontsleep(name varchar(10),fname varchar(10))");
    
    // int res=stat.executeUpdate("insert into dontsleep values('PFB','Beevs')");
    
   // int res=stat.executeUpdate("update dontsleep set fname='Priyanga' where name='SP'");
    
  //  int res=stat.executeUpdate("delete from dontsleep where name='KP'");
    ResultSet res=stat.executeQuery("select * from dontsleep order by name desc");
    while(res.next())
    {
    	System.out.println(res.getString(1)+" "+res.getString("fname"));
    }
 //  System.out.println("values inserted:"+res);
    //close the connection
    conn.close();
	
}
}
