import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Validation {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	System.out.println("Enter your username:");
	Scanner sc=new Scanner(System.in);
	String uname=sc.next();
	System.out.println("Enter the password:");
	String pass=sc.next();
	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	
	//create the connection
	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg401","training401");
	
	//create the statement
    PreparedStatement stat=conn.prepareStatement("select * from gmail where username=? and password=?");
   stat.setString(1,uname);
   stat.setString(2, pass);
    
    ResultSet res=stat.executeQuery();
    if(res.next()){
    		System.out.println("Login successful");
    	}
    else{
    	System.out.println("Enter valid credentials");
    }
    conn.close();
    } 
}

